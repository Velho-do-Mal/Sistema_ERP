
import bk_finance

# Reusa o app financeiro completo (com login, perfis e auditoria)
bk_finance.main()
